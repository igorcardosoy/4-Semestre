package br.edu.ifsp.arq.tsi.arqweb2.technicalassistance.model;

public class PaymentMethod {

    private Long code;
    private String name;

    public Long getCode() {
        return code;
    }

    public void setCode(Long code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
